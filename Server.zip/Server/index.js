const http = require('http');
const host = "127.0.0.1";
const port = 8000;
const fs = require('fs');
const s1 = http.createServer((req, res) => {
    if (req.url === "/" && req.method==='GET'){
        fs.readFile("./index.html",(err,data)=>{
            if(err){
                res.writeHead(404,{'Content-Type':'text/html'});
                res.write(`<h1>FILE NOT FOUND......</h1>`);
                res.end();
                return;
            }else{
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            }
        })
    }else if(req.url === "/form" && req.method==='GET'){
        fs.readFile("./form.html",(err,data)=>{
            if(err){
                res.writeHead(404,{'Content-Type':'text/html'})
                res.write(`<h1>FILE NOT FOUND......</h1>`);
                res.end();
                return;
            }else{
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            }
        })
    }else{
        res.end("We don't have this type route sorry.....")
    }
});
s1.listen(port, host, () => { console.log(`server started at http://${host}:${port}`) });
